# 🔬 Phase 0 Findings — Reverse Engineering the Orbit Repo

Date: 2026-10-08 · Status: ✅ extraction complete, one decision pending (wake-word package)

---

## 1. `assets.bin` — outer container (custom xiaozhi pack format)

Not real SPIFFS — a custom packer (from `78/xiaozhi-assets-generator`, `SpiffsGenerator.js`, mimicking Espressif's old `spiffs_assets_gen.py`):

```
header (12 B):  total_files(u32) | checksum(u32) | combined_data_length(u32)
mmap_table:     total_files × { name[32] | size(u32) | offset(u32) | width(u16) | height(u16) }   (44 B/entry)
file_data:      per file: 0x5A 0x5A marker + raw bytes; `offset` is relative to data region, points at the marker
checksum:       16-bit sum of all bytes after the 12-byte header (verified ✅)
```

Contents (both `assets.bin` and the device flash partition): exactly **2 files** — `srmodels.bin` + `index.json`.

## 2. `srmodels.bin` — inner container (esp-sr `pack_model.py` format)

From `WakenetModelPacker.js` (mimics esp-sr `pack_model.py`):

```
model_num (u32)
per model:  model_name[32] | file_count(u32) | per file { file_name[32] | file_start(u32) | file_len(u32) }
then all file data concatenated (starts right after the header)
```

Parsed contents (both packages, byte-exact totals verified ✅):

| Model | Files | Notes |
|---|---|---|
| `fst` | `commands_cn.txt` (7,298 B), `commands_en.txt` (2,350 B) | appliance command lists (identical md5 in both packages) — **to be dropped** (Chinese/command stuff removed) |
| `mn6_cn` *(assets.bin only)* | `_MODEL_INFO_` (158 B), `mn6_data` (3,682,928 B), `mn6_index` (4,008 B), `vocab` (6,601 B) | **Chinese** MultiNet6, `_MODEL_INFO_` = `MN6_v3_chinese_8_0.9_0.90` |
| `mn6_en` *(device flash only)* | `_MODEL_INFO_` (159 B), `mn6_data` (3,766,762 B), `mn6_index` (4,032 B), `vocab` (7,314 B) | **English** MultiNet6, `_MODEL_INFO_` = `MN6_v11_english_8_0.9_0.90` |

## 3. How the "Orbit" wake word actually works

- There is **no custom-trained weight** and no literal `orbit` string anywhere in the models.
- The wake word is a **stock Espressif MultiNet6 acoustic model** + a runtime command entry in `index.json`:
  ```json
  "multinet_model": { "language": "cn"|"en", "duration": 3000, "threshold": 0.2,
    "commands": [ { "command": "Orbit", "text": "Orbit", "action": "wake" } ] }
  ```
- At runtime, ESP-SR MultiNet builds an FST from the command string and matches it **phonetically** against the acoustic model output.
- Evidence: `mn6_en` vocab (496 units) contains the phonemes needed for "orbit" (`O`, `R`, `B`, `T`, `ER`, …). `mn6_cn` vocab (408 units) is pinyin syllables.

## 4. ⚠️ `assets.bin` vs device flash — they differ!

| | `assets.bin` (repo) | device flash (`firmware_backup.bin` @0x800000) |
|---|---|---|
| MultiNet model | `mn6_cn` (Chinese, v3) | `mn6_en` (English, v11) |
| `index.json` language | `"cn"` | `"en"` |
| `index.json` wake command | `"Orbit" → wake` | `"Orbit" → wake` |
| `index.json` other fields | identical (only `language` differs) | identical |
| `srmodels.bin` size | 3,703,659 B | 3,788,231 B |

**Analysis:** "Orbit" is an English word. The English MultiNet6 model (`mn6_en`) is the correct acoustic model for it — the Chinese model (`mn6_cn`) would match it with pinyin phonetics (wrong/weak). The device flash package (`mn6_en` + `language: en`) is exactly what the xiaozhi console generates for an English custom wake word, and it is what the running device currently uses.

**Recommendation:** use the **device-flash package (`mn6_en`)** for the new firmware. The `assets.bin` (`mn6_cn`) package is kept as fallback.

## 5. Phase 0 output — what the new firmware keeps

- ✅ Keep: the `mn6_*` model files (`_MODEL_INFO_`, `mn6_data`, `mn6_index`, `vocab`) + `index.json` (wake command `Orbit`)
- ❌ Drop: `fst` model (`commands_cn.txt`, `commands_en.txt`) — old appliance command lists; the new assistant does NLU in Gemini, no on-device command recognition. This also removes the Chinese command stuff at the root.
- ℹ️ Note: "Chinese stuff" = the command lists + CN language config. The `mn6` model that carries the `Orbit` wake word must stay (it *is* the wake word).

## 6. Tools written

- `tools/extract_assets.py` — unpacks `assets.bin` (also auto-slices the assets partition out of a full flash dump)
- `tools/extract_srmodels.py` — unpacks `srmodels.bin` into per-model files
- `research/` — reference sources: `SpiffsGenerator.js`, `WakenetModelPacker.js`, `AssetsBuilder.js` (xiaozhi-assets-generator), `spiffsgen.py` (ESP-IDF)

## 7. Extracted file tree

```
assets/
├── extracted/                  # from repo assets.bin
│   ├── srmodels.bin            #   └─ models: fst + mn6_cn
│   └── index.json              #     language: "cn", wake: "Orbit"
├── extracted-from-device/      # from firmware_backup.bin assets partition
│   ├── srmodels.bin            #   └─ models: fst + mn6_en
│   └── index.json              #     language: "en", wake: "Orbit"
├── models-from-assets/         # parsed sub-models (fst/, mn6_cn/)
└── models-from-device/         # parsed sub-models (fst/, mn6_en/)
```
